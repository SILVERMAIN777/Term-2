function mover(a)  {
	if (document.images)  {
	switch(a)  {
		case 1:
			document.main.src = "../ris/2main.gif"
			return 0;
		case 2:
			document.map.src = "../ris/2map.gif"
			return 0;
		case 3:
			document.about.src = "../ris/2about.gif"
			return 0;
		case 4:
			document.photo.src = "../ris/2phot.gif"
			return 0;
		case 5:
			document.crazy.src = "../ris/2shiz.gif"
			return 0;
		case 6:
			document.jokes.src = "../ris/2pric.gif"
			return 0;
		case 7:
			document.info.src = "../ris/2inf.gif"
			return 0;
		case 8:
			document.scripts.src = "../ris/2scripts.gif"
			return 0;
		case 9:
			document.programs.src = "../ris/2prog.gif"
			return 0;
		case 10:
			document.mp3.src = "../ris/2mp3.gif"
			return 0;
		case 11:
			document.enjoy.src = "../ris/2enjoy.gif"
			return 0;
		case 12:
			document.links.src = "../ris/2links.gif"
			return 0;
		case 13:
			document.misc.src = "../ris/2misc.gif"
			return 0;
		case 14:
			document.guest.src = "../ris/2gost.gif"
			return 0;
		case 15:
			document.members.src = "../ris/2mem.gif"
			return 0;
			}
		}
	}
function mout(a)  {
	if (document.images)  {
	switch(a)  {
		case 1:
			document.main.src = "../ris/1main.gif"
			return 0;
		case 2:
			document.map.src = "../ris/1map.gif"
			return 0;
		case 3:
			document.about.src = "../ris/1about.gif"
			return 0;
		case 4:
			document.photo.src = "../ris/1photo.gif"
			return 0;
		case 5:
			document.crazy.src = "../ris/1shiz.gif"
			return 0;
		case 6:
			document.jokes.src = "../ris/1pric.gif"
			return 0;
		case 7:
			document.info.src = "../ris/1inf.gif"
			return 0;
		case 8:
			document.scripts.src = "../ris/1scripts.gif"
			return 0;
		case 9:
			document.programs.src = "../ris/1prog.gif"
			return 0;
		case 10:
			document.mp3.src = "../ris/1mp3.gif"
			return 0;
		case 11:
			document.enjoy.src = "../ris/1enj.gif"
			return 0;
		case 12:
			document.links.src = "../ris/1links.gif"
			return 0;
		case 13:
			document.misc.src = "../ris/1misc.gif"
			return 0;
		case 14:
			document.guest.src = "../ris/1gost.gif"
			return 0;
		case 15:
			document.members.src = "../ris/1mem.gif"
			return 0;
		}
	}
	}
function preloadImages()  {
	if (document.images)  {
	var ImagesArray = new Array();
		for (k=0;k<15;k++)  {
			ImagesArray[k] = new Image();
			if (k==0) ImagesArray[k].src = "../ris/2main.gif";
			if (k==1) ImagesArray[k].src = "../ris/2map.gif";
			if (k==2) ImagesArray[k].src = "../ris/2about.gif";
			if (k==3) ImagesArray[k].src = "../ris/2phot.gif";
			if (k==4) ImagesArray[k].src = "../ris/2shiz.gif";
			if (k==5) ImagesArray[k].src = "../ris/2pric.gif";
			if (k==6) ImagesArray[k].src = "../ris/2inf.gif";
			if (k==7) ImagesArray[k].src = "../ris/2scripts.gif";
			if (k==8) ImagesArray[k].src = "../ris/2prog.gif";
			if (k==9) ImagesArray[k].src = "../ris/2mp3.gif";
			if (k==10) ImagesArray[k].src = "../ris/2enjoy.gif";
			if (k==11) ImagesArray[k].src = "../ris/2links.gif";
			if (k==12) ImagesArray[k].src = "../ris/2misc.gif";
			if (k==13) ImagesArray[k].src = "../ris/2gost.gif";
			if (k==14) ImagesArray[k].src = "../ris/2mem.gif";
			}
		return ImagesArray
		}
	}