arrOptions=new Array(
  ["ajax","1"],
  ["in","2"],
  ["action","3"],
  ["dummy","4"],
  ["data","5"]
);

