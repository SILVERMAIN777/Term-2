var name='earth';
var description="A small blue planet near the outer rim of the galaxy, third planet out from a middle-sized sun.";

var win=top.showPopup(name,description);
