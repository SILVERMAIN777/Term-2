var name='jupiter';
var description="A really big, huge planet, with loads of moons, orbiting the same sun as the Earth. A gas giant, Jupiter has no solid surface as such.\n\nFour of the moons are large enough to be seen from the Earth, and were first discovered by Galileo.\n\nNamed after the Roman god Jupiter, originally known by the Greeks as Zeus.";

var win=top.showPopup(name,description);
