create TABLE contacts(
  id INT,
  companyName VARCHAR(255),
  contactName VARCHAR(255),
  country VARCHAR(255),
  phone VARCHAR(255)
);

INSERT INTO Contacts VALUES(1,'sunwheel','dave','uk','12345678');
INSERT INTO Contacts VALUES(2,'self-employed','eric','us','12345678');
INSERT INTO Contacts VALUES(3,'yahoo','darren','us','12345678');
INSERT INTO Contacts VALUES(4,'argives','aias','greece','12345678');
INSERT INTO Contacts VALUES(5,'argives','ulysses','greece','12345678');
INSERT INTO Contacts VALUES(6,'argives','achilles','greece','12345678');
INSERT INTO Contacts VALUES(7,'avengers','hulk','us','12345678');
INSERT INTO Contacts VALUES(8,'avengers','thor','us','12345678');
INSERT INTO Contacts VALUES(9,'avengers','john steed','uk','12345678');
INSERT INTO Contacts VALUES(10,'avengers','mrs. peel','uk','12345678');
INSERT INTO Contacts VALUES(11,'sherwood','robin hood','uk','12345678');
INSERT INTO Contacts VALUES(12,'sherwood','little john','uk','12345678');
INSERT INTO Contacts VALUES(13,'sherwood','friar tuck','uk','12345678');
INSERT INTO Contacts VALUES(14,'sherwood','alan-a-dale','uk','12345678');
INSERT INTO Contacts VALUES(15,'sherwood','maid marian','uk','12345678');
INSERT INTO Contacts VALUES(16,'sherwood','will scarlet','uk','12345678');

